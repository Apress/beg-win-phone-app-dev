﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO;
using System.Text;

namespace SSLConnection
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            string pageURL = "https://www.paypal.com";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(pageURL);
            request.Method = "GET";
            request.BeginGetResponse(HandleResponse, request);
        }

        void HandleResponse(IAsyncResult result)
        {
            StreamReader reader = null;
            HttpWebResponse httpResponse = (HttpWebResponse)(((HttpWebRequest)result.AsyncState).EndGetResponse(result));
            reader = new StreamReader(httpResponse.GetResponseStream(), Encoding.UTF8);

            string pageResponse = reader.ReadToEnd();
            Dispatcher.BeginInvoke(() => webBrowser1.NavigateToString(pageResponse));
        }
    }
}
