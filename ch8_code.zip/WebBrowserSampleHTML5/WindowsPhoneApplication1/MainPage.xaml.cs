﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO.IsolatedStorage;
using System.Windows.Resources;
using System.IO;

namespace WindowsPhoneApplication1
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            webBrowser1.IsScriptEnabled = true;
            webBrowser1.IsGeolocationEnabled = true;

            webBrowser1.Loaded += webBrowser1_Loaded;
        }

        void webBrowser1_Loaded(object sender, RoutedEventArgs e)
        {
            webBrowser1.NavigateToString(@"
                                            <!DOCTYPE html>                                            
                                            <html>
                                              <head>
                                                <META name='MobileOptimized' content='320' />
                                              </head>
                                              <body>
                                                <canvas id='myCanvas' width='200' height='100' style='border:1px solid #c3c3c3;'>
                                                  Your browser does not support the canvas element.
                                                </canvas>

                                                <audio src='http://www.eugenechuvyrov.com/iheartwp/punk.mp3' controls='true'>                                             
                                                  Your browser does not support the audio element.
                                                </audio>

                                                <div id='message'>
                                                    geolocation data will be shown here
                                                </div>

                                                <script type='text/javascript'>
                                                  var c=document.getElementById('myCanvas');
                                                  var cxt=c.getContext('2d');
                                                  cxt.fillStyle='#FF0000';
                                                  cxt.beginPath();
                                                  cxt.arc(70,18,15,0,Math.PI*2,true);
                                                  cxt.closePath();
                                                  cxt.fill();

                                                  navigator.geolocation.getCurrentPosition(onPositionReady);

                                                  function onPositionReady(position) {
                                                    document.getElementById('message').innerHTML = 'lat ' + position.coords.latitude + ' long ' + 
                                                        position.coords.longitude;
                                                  }

                                                </script>                    

                                              </body>
                                            </html>
                                            ");
        }

    }
}
