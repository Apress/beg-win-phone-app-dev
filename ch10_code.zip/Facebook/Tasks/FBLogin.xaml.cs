﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Reactive;
using System.IO;
using System.Diagnostics;
using System.Text;

namespace Tasks
{
    public partial class FBLogin : PhoneApplicationPage
    {
        const string STR_FB_Permissions = "publish_stream";
        const string STR_FB_SuccessUrl = "http://www.facebook.com/connect/login_success.html";
        const string STR_FB_Login = "https://graph.facebook.com/oauth/authorize?display=wap&client_id={0}&redirect_uri={1}&scope={2}";
        const string FB_GetAccessToken = "https://graph.facebook.com/oauth/access_token?client_id={0}&redirect_uri={1}&client_secret={2}&code={3}";

        const string STR_Post = "POST";
        const string STR_Access_token = "access_token";
        const string STR_FB_AppId = "151976448193007";
        const string FB_AppSecret = "33d935e890fd6a5be619e5bceb76aa38";
        const string STR_FormEncoded = "application/x-www-form-urlencoded";

        public FBLogin()
        {
            InitializeComponent();

            this.Loaded += (sender, args) =>
            {
                var url = string.Format(STR_FB_Login, STR_FB_AppId, HttpUtility.UrlEncode(STR_FB_SuccessUrl), STR_FB_Permissions);
                IObservable<IEvent<NavigationEventArgs>> FBResponse;

                //register a subscription to FaceBook navigated event
                FBResponse = Observable.FromEvent<NavigationEventArgs>(webBrowser1, "Navigated");
                FBResponse.ObserveOn(Deployment.Current.Dispatcher)
                    .Subscribe(evt =>
                    {
                        //on successful user authentication event only
                        if (evt.EventArgs.Uri.ToString().StartsWith(STR_FB_SuccessUrl))
                        {
                            //1. get a session ID from the query string
                            var sessionId = evt.EventArgs.Uri.Query.Substring("?code=".Length);

                            //get the user and compose an authentication token request
                            string strTokenId = GetGraphToken(sessionId);
                            string strMessage = String.Empty;
                            NavigationContext.QueryString.TryGetValue("MessageToPost", out strMessage);

                            //2. get OAuth authentication token and use it to update user's Facebook wall
                            UpdateWall("POST", strTokenId, strMessage);
                            NavigationService.GoBack();
                        }
                    },
                    ex =>
                    {
                        //log/process exceptions here

                    }
                );

                //invoke the navigation process
                webBrowser1.Navigate(new Uri(url, UriKind.Absolute));
            };
        }

        public static void UpdateWall(string method, string url, string postData)
        {
            var webRequest = WebRequest.Create(url) as HttpWebRequest;
            webRequest.Method = method;

            if (method == STR_Post)
            {
                webRequest.ContentType = STR_FormEncoded;

                // request an authentication token
                Observable.FromAsyncPattern<WebResponse>(
                            webRequest.BeginGetResponse,
                            webRequest.EndGetResponse)()
                            .Subscribe(
                            wr =>
                            {
                                try
                                {
                                    // upon completion of request for authentication token, parse out access token
                                    using (var responseReader = new StreamReader(wr.GetResponseStream()))
                                    {
                                        string strOutput = responseReader.ReadToEnd();

                                        // use access token to compose the request to post to user's Wall
                                        var payload = string.Format("{0}&message={1}&caption={2}&link={3}&name={4}", strOutput, "My WP7 App: \n\n" + postData, "WP7 App", "http://www.windowsphone.com", "WP7 Facebook Integration");
                                        var uri = new Uri(string.Format("https://graph.facebook.com/me/feed?{0}", payload));

                                        var wc = new WebClient { Encoding = Encoding.UTF8 };
                                        Observable.FromEvent<UploadStringCompletedEventArgs>(wc, "UploadStringCompleted")
                                            .Subscribe(evt =>
                                            {
                                                try
                                                {
                                                    if (evt.EventArgs.Result != null)
                                                    {
                                                        //successfully updated wall, print SUCCESS message into Debug window
                                                        Debug.WriteLine("SUCCESS!");
                                                    }
                                                }
                                                catch (WebException ex)
                                                {
                                                    StreamReader readStream = new StreamReader(ex.Response.GetResponseStream());
                                                    Debug.WriteLine(readStream.ReadToEnd());
                                                    //This way wee can see the error message from facebook
                                                }
                                            },
                                            ex =>
                                            {

                                            }
                                        );

                                        wc.UploadStringAsync(uri, null, payload);
                                    }

                                }
                                catch (WebException ex)
                                {
                                    StreamReader readStream = new StreamReader(ex.Response.GetResponseStream());
                                    //Get the error message from Facebook
                                    Debug.WriteLine(readStream.ReadToEnd());
                                }
                            });
            }
        }

        public static string GetGraphToken(string sessionId)
        {
            string strAccessTokenUrl = "";

            try
            {
                strAccessTokenUrl = string.Format(FB_GetAccessToken, STR_FB_AppId, STR_FB_SuccessUrl, FB_AppSecret, sessionId);
            }
            catch (Exception exc)
            {
                System.Diagnostics.Debug.WriteLine("ERROR: " + exc.Message);
                System.Diagnostics.Debug.WriteLine(exc.StackTrace);
            }

            return strAccessTokenUrl;
        }

    }
}