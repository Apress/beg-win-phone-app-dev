﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Devices;
using System.Threading;
using System.Windows.Media.Imaging;

namespace NegativePhoto
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Variables
        PhotoCamera _camera = new PhotoCamera();
        private static ManualResetEvent _pauseEvent = new ManualResetEvent(true);
        private WriteableBitmap _writeableBitmap;
        private Thread _ARGBFramesThread;
        private bool _pumpARGBFrames;

        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        //Code for camera initialization event, and setting the source for the viewfinder
        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {

            // Check to see if the camera is available on the device.
            if ((PhotoCamera.IsCameraTypeSupported(CameraType.Primary) == true) ||
                 (PhotoCamera.IsCameraTypeSupported(CameraType.FrontFacing) == true))
            {
                // Initialize the default camera.
                _camera = new Microsoft.Devices.PhotoCamera();

                //Event is fired when the PhotoCamera object has been initialized
                _camera.Initialized += new EventHandler<CameraOperationCompletedEventArgs>(_cam_Initialized);

                //Set the VideoBrush source to the camera
                viewfinderBrush.SetSource(_camera);
            }
            else
            {
                // The camera is not supported on the device.
                this.Dispatcher.BeginInvoke(delegate()
                {
                    // Write message.
                    txtDebug.Text = "A Camera is not available on this device.";
                });

                // Disable UI.
                GrayscaleOnButton.IsEnabled = false;
                GrayscaleOffButton.IsEnabled = false;
            }
        }

        private void _cam_Initialized(object sender, CameraOperationCompletedEventArgs e)
        {
            if (e.Succeeded)
            {
                this.Dispatcher.BeginInvoke(delegate()
                {
                    txtDebug.Text = "Camera initialized successfully";
                });
            }
        }

        protected override void OnNavigatingFrom(System.Windows.Navigation.NavigatingCancelEventArgs e)
        {
            if (_camera != null)
            {
                // Dispose of the camera to minimize power consumption and to expedite shutdown.
                _camera.Dispose();

                // Release memory, ensure garbage collection.
                _camera.Initialized -= _cam_Initialized;
            }
        }

        // ARGB frame pump
        private void PumpARGBFrames()
        {
            // Create capture buffer.
            int[] ARGBPx = new int[(int)_camera.PreviewResolution.Width * (int)_camera.PreviewResolution.Height];

            try
            {
                PhotoCamera phCam = (PhotoCamera)_camera;

                while (_pumpARGBFrames)
                {
                    _pauseEvent.WaitOne();

                    // Copies the current viewfinder frame into a buffer for further manipulation.
                    phCam.GetPreviewBufferArgb32(ARGBPx);

                    // Conversion to grayscale.
                    for (int i = 0; i < ARGBPx.Length; i++)
                    {
                        ARGBPx[i] = ColorToNegative(ARGBPx[i]);
                    }

                    _pauseEvent.Reset();
                    Deployment.Current.Dispatcher.BeginInvoke(delegate()
                    {
                        // Copy to WriteableBitmap.
                        ARGBPx.CopyTo(_writeableBitmap.Pixels, 0);
                        _writeableBitmap.Invalidate();

                        _pauseEvent.Set();
                    });
                }

            }
            catch (Exception e)
            {
                this.Dispatcher.BeginInvoke(delegate()
                {
                    // Display error message.
                    txtDebug.Text = e.Message;
                });
            }
        }

        private int ColorToNegative(int color)
        {
            int a, r, g, b;
            GetARGB(color, out a, out r, out g, out b);

            r = 255 - r;
            g = 255 - g;
            b = 255 - b;

            int result = GetColorFromArgb(a, r, g, b);

            return result;
        }

        private void btnNegativeOn_Click(object sender, RoutedEventArgs e)
        {
            MainImage.Visibility = Visibility.Visible;
            _pumpARGBFrames = true;
            _ARGBFramesThread = new System.Threading.Thread(PumpARGBFrames);

            _writeableBitmap = new WriteableBitmap((int)_camera.PreviewResolution.Width, (int)_camera.PreviewResolution.Height);
            this.MainImage.Source = _writeableBitmap;

            // Start pump.
            _ARGBFramesThread.Start();
            this.Dispatcher.BeginInvoke(delegate()
            {
                txtDebug.Text = "ARGB to Negative";
            });
        }

        private void btnNegativeOff_Click(object sender, RoutedEventArgs e)
        {
            MainImage.Visibility = Visibility.Collapsed;
            _pumpARGBFrames = false;

            this.Dispatcher.BeginInvoke(delegate()
            {
                txtDebug.Text = "";
            });
        }

        private void GetARGB(int color, out int a, out int r, out int g, out int b)
        {
            a = color >> 24;
            r = (color & 0x00ff0000) >> 16;
            g = (color & 0x0000ff00) >> 8;
            b = (color & 0x000000ff);
        }

        /// <summary>
        /// Assemble the ARGB values to one color value 
        /// </summary>
        /// <param name="a">Alpha component value</param>
        /// <param name="r">Red component value</param>
        /// <param name="g">Green component value</param>
        /// <param name="b">Blue component value</param>
        /// <returns>One color value from the given ARGB</returns>
        private int GetColorFromArgb(int a, int r, int g, int b)
        {
            int result = ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
            return result;
        }
    }
}