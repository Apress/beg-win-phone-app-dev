﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Reactive;
using System.Threading;
using System.Diagnostics;
using WeatherRx.svcWeather;
using System.Xml.Linq;

namespace WeatherRx
{
    public partial class MainPage : PhoneApplicationPage
    {
        svcWeather.GlobalWeatherSoapClient weatherClient = new svcWeather.GlobalWeatherSoapClient();
        IObservable<IEvent<KeyEventArgs>> _keys;
        const string conCountry = "United States";

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            WireUpWeatherEvents();
            WireUpKeyEvents();
        }
        
        private void WireUpWeatherEvents()
        {
            GetKeys();
            var latestWeather = (from term in _keys
                       select GetWeatherSubject()
                          .Finally(() =>
                          {
                            Deployment.Current.Dispatcher.BeginInvoke(() => Debug.WriteLine("Disposed of prior subscription"));
                          })
             ).Switch(); 

            latestWeather.ObserveOnDispatcher()
                .Subscribe(evt =>
                {
                    if (evt.EventArgs.Result!= null)
                    {
                        string strXMLResult = evt.EventArgs.Result;
                        XElement weatherElements = XElement.Parse(strXMLResult);
                        string strTemperature = weatherElements.Element("Temperature").Value;
                        string strWind = weatherElements.Element("Wind").Value;

                        lblTemperature.Text = "Current Temperature: " + strTemperature;
                        lblWind.Text = "Current Wind: " + strWind;
                    }
                },
                ex => {
                            Deployment.Current.Dispatcher.BeginInvoke(() =>lblStatus.Text = ex.Message);
                        }                
            );
        }

        private IObservable<IEvent<GetWeatherCompletedEventArgs>> GetWeatherSubject()
        {           
            return Observable.FromEvent<svcWeather.GetWeatherCompletedEventArgs>(weatherClient, "GetWeatherCompleted");
        }

        private void GetKeys()
        {
            if (_keys == null)
            {
                _keys = Observable.FromEvent<KeyEventArgs>(txtCityName, "KeyUp").Throttle(TimeSpan.FromSeconds(1)).DistinctUntilChanged();
            }
        }

        private void WireUpKeyEvents()
        {
            GetKeys();
            _keys.ObserveOn(Deployment.Current.Dispatcher).Subscribe(evt =>
            {
                if (txtCityName.Text.Length >= 5)
                {
                    weatherClient.GetWeatherAsync(txtCityName.Text, conCountry);
                }
            });
        }

        private void btnRetry_Click(object sender, RoutedEventArgs e)
        {
            btnQuit.Visibility = System.Windows.Visibility.Collapsed;
            btnRetry.Visibility = System.Windows.Visibility.Collapsed;
            lblStatus.Text = "";

            WireUpWeatherEvents();
            weatherClient.GetWeatherAsync(txtCityName.Text, conCountry);
        }

        private void btnQuit_Click(object sender, RoutedEventArgs e)
        {
            btnQuit.Visibility = System.Windows.Visibility.Collapsed;
            btnRetry.Visibility = System.Windows.Visibility.Collapsed;
            lblStatus.Text = "";

        }
    }
}
