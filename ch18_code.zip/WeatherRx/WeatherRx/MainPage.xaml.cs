﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Reactive;
using System.Threading;
using System.Diagnostics;
using System.Windows.Media.Imaging;
using WeatherRx.svcWeather;
using System.Xml.Linq;
using System.Collections;

namespace WeatherRx
{
    public partial class MainPage : PhoneApplicationPage
    {
        svcWeather.GlobalWeatherSoapClient weatherClient = new svcWeather.GlobalWeatherSoapClient();
        IObservable<IEvent<GetWeatherCompletedEventArgs>> _weather;
        const string conCountry = "United States";

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            //WireUpWeatherEvents();
            WireUpKeyEvents();
        }

        private void WireUpWeatherEvents()
        {
            GetWeatherSubject();
            _weather.ObserveOn(Deployment.Current.Dispatcher)
                .Timeout(TimeSpan.FromSeconds(300))
                .Subscribe(evt =>
                {
                    if (evt.EventArgs.Result!= null)
                    {
                        string strXMLResult = evt.EventArgs.Result;
                        XElement weatherElements = XElement.Parse(strXMLResult);
                        string strTemperature = weatherElements.Element("Temperature").Value;
                        string strWind = weatherElements.Element("Wind").Value;

                        lblTemperature.Text = "Current Temperature: " + strTemperature;
                        lblWind.Text = "Current Wind: " + strWind;
                    }
                },
                ex =>
                {
                    Deployment.Current.Dispatcher.BeginInvoke(() => lblStatus.Text = ex.Message);
                    Deployment.Current.Dispatcher.BeginInvoke(() => btnQuit.Visibility=System.Windows.Visibility.Visible);
                    Deployment.Current.Dispatcher.BeginInvoke(() => btnRetry.Visibility = System.Windows.Visibility.Visible);
                }
            );
        }

        private void GetWeatherSubject()
        {
            if (_weather == null)
            {
                _weather = Observable.FromEvent<svcWeather.GetWeatherCompletedEventArgs>(weatherClient, "GetWeatherCompleted");
            }
        }

        private void WireUpKeyEvents()
        {
            var keys = Observable.FromEvent<KeyEventArgs>(txtCityName, "KeyUp").Throttle(TimeSpan.FromSeconds(1)).DistinctUntilChanged();
            keys.ObserveOn(Deployment.Current.Dispatcher).Subscribe(evt =>
            {
                if (txtCityName.Text.Length >= 5)
                {
                    WireUpWeatherEvents();
                    weatherClient.GetWeatherAsync(txtCityName.Text, conCountry);
                }
            });
        }

        private void btnRetry_Click(object sender, RoutedEventArgs e)
        {
            btnQuit.Visibility = System.Windows.Visibility.Collapsed;
            btnRetry.Visibility = System.Windows.Visibility.Collapsed;
            lblStatus.Text = "";

            WireUpWeatherEvents();
            weatherClient.GetWeatherAsync(txtCityName.Text, conCountry);
        }

        private void btnQuit_Click(object sender, RoutedEventArgs e)
        {
            btnQuit.Visibility = System.Windows.Visibility.Collapsed;
            btnRetry.Visibility = System.Windows.Visibility.Collapsed;
            lblStatus.Text = "";

        }
    }
}
