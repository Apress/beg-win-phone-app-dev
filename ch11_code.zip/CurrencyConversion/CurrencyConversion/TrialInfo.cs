﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace CurrencyConversion
{
    public static class TrialInfo
    {
        public static bool IsTrial
        {
            get
            {
#if DEBUG
                return true;
#else
                LicenseInformation lic = new LicenseInformation();
                return lic.IsTrial();
#endif
            }

            set
            {
                IsTrial = value;
            }
        }
    }
}
